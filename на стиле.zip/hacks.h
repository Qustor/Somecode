#pragma once HACKS_H


#include <iostream>
#include <Windows.h>
#include <TlHelp32.h>
#include <vector>
#include <conio.h>


//void killcooldown() {
//
//    if (amgkillcooldown < 1)
//    {
//        amgkillcooldown = 1;
//    }
//
//    if (amgkillcooldown > 30)
//    {
//        amgkillcooldown = 30;
//    }
//
//    if (GetAsyncKeyState(VK_NUMPAD5) & 1)
//    {
//        Sleep(100);
//        amgkillcooldown++;
//    }
//
//    if (GetAsyncKeyState(VK_NUMPAD4) & 1)
//    {
//        Sleep(100);
//        --amgkillcooldown;
//    }
//    
//    uintptr_t dynamicptrbaseaddr = ModuleBase + 0x1CBA440;
//    std::vector<unsigned int> speedcooldownoffset = { 0x5C, 0x4, 0x20 };
//
//
//    uintptr_t myAddr = FindDMAAddy(hProcess, dynamicptrbaseaddr, speedcooldownoffset);
//
//
//    WriteProcessMemory(hProcess, (LPVOID)myAddr, &amgkillcooldown, sizeof(amgkillcooldown), 0);
//}


void addmoney() {

    if (money < 100000)
    {
        money = 100000;
    }
    
    if (GetAsyncKeyState(VK_NUMPAD7) & 10000)
    {
        Sleep(100);
        money++;
    }

    uintptr_t dynamicptrbaseaddr = ModuleBase + 0x1139F08;
    std::vector<unsigned int> moneyoffset = { 0x1B8 };


    uintptr_t myAddr = FindDMAAddy(hProcess, dynamicptrbaseaddr, moneyoffset);


    WriteProcessMemory(hProcess, (LPVOID)myAddr, &money, sizeof(money), 0);

}

void health() {


    if (plhealth < 100)
    {
        plhealth = 100;
    }

     if (plhealth > 150)
    {
         plhealth = 150;
    }
  /*  if (GetAsyncKeyState(VK_NUMPAD2) & 1) 
    {
               Sleep(100);
               infinityammo++;
    }

    if (GetAsyncKeyState(VK_NUMPAD1) & 1)
    {
        Sleep(100);
        --infinityammo;
    }*/



    uintptr_t dynamicptrbaseaddr = PlayerBase + 0x6BEAFC;
    std::vector<unsigned int> healthoffset = { 0x6D4, 0xA0, 0x5C, 0x28 , 0x1C , 0x60 , 0xCC};


    uintptr_t myAddr = FindDMAAddy(hProcess, dynamicptrbaseaddr, healthoffset);


    WriteProcessMemory(hProcess, (LPVOID)myAddr, &plhealth, sizeof(plhealth), 0);
}


//void moneysize() {
//
//    if (GetAsyncKeyState(VK_NUMPAD4) & 500) {
//        Sleep(100);
//        money++;
//    }
//
//
//
//    uintptr_t dynamicptrbaseaddr = ModuleBase + 0x1A9924;
//    std::vector<unsigned int> moneyoffset = { 0x24, 0x48, 0x10, 0x8C, 0x14 };
//
//
//    uintptr_t myAddr = FindDMAAddy(hProcess, dynamicptrbaseaddr, moneyoffset);
//
//
//    WriteProcessMemory(hProcess, (LPVOID)myAddr, &money, sizeof(money), 0);
//}

