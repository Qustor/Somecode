﻿#include <iostream>
#include <Windows.h>
#include <TlHelp32.h>
#include <vector>
#include <conio.h>
#include "addy.h" //библио с адресами к которым я обращаюсь
#include "hacks.h" //функции с оффсетами {хаксами}
#include <chrono>
using namespace std;


int main() {
    SetConsoleTitle("Trainer for BL2 Last Vers(Epic/Steam)"); 

    //cout << "[!!!] Open Borderlands 2";

    while (!hwnd)
    {
        hwnd = FindWindow(0, "Borderlands 2 (32-bit, DX9)");
    }

    if (!hwnd) 
    {
        cout << "\n\n [###] Open Borderlands 2" << endl;
        Sleep(1000);
        return 0;
    }
    
    procID = 0;
    GetWindowThreadProcessId(hwnd, &procID);

    if (!procID)  
    {
        cout << "\n\n [###] Open Borderlands 2" << endl;
        Sleep(100000);
        return 0;
    }


    ModuleBase = GetModuleBaseAddress("Borderlands2.exe");
    PlayerBase = GetModuleBaseAddress("client.dll");
    hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, procID);


    if (!hProcess)
    {
        cout << "\n\n [###] Open Borderlands 2" << endl;
        Sleep(1000);
        return 0;
    }

    cout << "[+++] Borderlands 2 is ^opened^" << endl;

    cout << "\n\n [***] ur money: " << money;
    /*cout << "\n\n [***] ur health: " << plhealth;
    cout << "\n\n [***] ur kill cooldown: " << amgkillcooldown;*/

    while (true) {

        /*killcooldown();
        health();*/
        addmoney();
        //ImposterNow();
        //NoCoolDown();
    }

    system("pause");
    _getch();
    return 0;

}